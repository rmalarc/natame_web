#!/usr/bin/perl
use Asterisk::AGI;
use DBI;

$AGI = new Asterisk::AGI;
%input = $AGI->ReadParse();

#get called extension
$EXTEN = $AGI->get_variable("ARG3");
if (!$EXTEN){
	$EXTEN = $AGI->get_variable("ARG2");
}


#connect to mysql db to retrieve extension fwd preferences
$dbh = DBI->connect("dbi:mysql:dbname=asterisk","root","ast3rix")||die "unable to connect to DB";

$query = "select FWD from callforward where EXTEN = '".$EXTEN."' and FWD <> ''";

my $db_query = $dbh->prepare($query)||die "Error Preparing";

$db_query->execute()||die "Error Executing";

@fwdinfo=$db_query->fetchrow_array();
$FWDTO = @fwdinfo[0];


#choose fwd destination

$AGI->verbose("callforward exten ".$EXTEN." wants to be fwd to ".$FWDTO);

$DIALSTRING = "";

if ($FWDTO){
	if (length($FWDTO)==4){
		$AGI->verbose("TRANSFER CALL  TO: ".$FWDTO );
		$AGI->exec('Goto',"internal|$FWDTO|1");
		fflush;
		exit;		
	}
	$TRUNK = $AGI->get_variable("TRUNK");
	$DIALSTRING = "$TRUNK/$FWDTO&";
	$CALLERID = $AGI->get_variable("CALLERIDNUM");
	$AGI->exec('SetCallerID',$CALLERID); 

} 

$DIALDEST = $AGI->get_variable("ARG1");
$DIALSTRING .= "$DIALDEST|20|t";

$AGI->verbose("CALLFORWARD.PL - DIALING ".$DIALSTRING);
$AGI->exec('Dial',$DIALSTRING);



fflush;


