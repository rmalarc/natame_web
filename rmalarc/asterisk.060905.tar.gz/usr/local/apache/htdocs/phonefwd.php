<?

//Get variables to be used

$GETFWD = $_POST["GETFWD"];
$SETFWD = $_POST["SETFWD"];
$CLEARFWD = $_POST["CLEARFWD"];
$EXTEN = $_POST["EXTEN"];
$FWD = $_POST["FWD"];
$SETDEFAULT = $_POST["SETDEFAULT"];


// establish DB connection
$link = mysql_pconnect('localhost', 'root', 'ast3rix')
   or die('Could not connect: ' . mysql_error());
mysql_select_db('asterisk') or die('Could not select database');

//take the appropiate action
if ($GETFWD){
	$query = "SELECT * FROM callforward where EXTEN = '$EXTEN'";
	$result = mysql_query($query) or die('Query failed: ' . mysql_error());
	$option = mysql_fetch_array($result, MYSQL_ASSOC);
	$FWD = $option{FWD};
} elseif ($CLEARFWD){
//	$query = "UPDATE callforward SET FWD = '' where EXTEN = '$EXTEN'";
	$query = "delete from  callforward where EXTEN = '$EXTEN'";
	$result = mysql_query($query) or die('Query failed: ' . mysql_error());
	$FWD="";
} elseif ($SETFWD){
	$query = "UPDATE callforward SET FWD = '$FWD' where EXTEN = '$EXTEN'";
	$result = mysql_query($query) or die('Query failed: ' . mysql_error());
	if (!mysql_affected_rows()){
	  $query = "insert into callforward(EXTEN,FWD) values ('$EXTEN','$FWD')";
	  $result = mysql_query($query);
// or die('Query failed: ' . mysql_error());
	}
}

print <<<EOF

<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Phone Forwarding Options</title>
<link rel="stylesheet" href="http://surgecorp.surging.com/stylesheet/pcstyles.css">
</head>

<body bgColor="#EEEEEE">
<form method="POST" action="$PHP_SELF" class="bodytext">
	<div align="center">
		<table border="1" width="1" cellspacing="0" cellpadding="0" bordercolorlight="#FFFFFF" bordercolordark="#FFFFFF" bgColor="#FFFFFF">
			<tr align="left"><td>
		<table border="0" width="1" id="table1" cellspacing="5" cellpadding="0" bordercolorlight="#FFFFFF" bordercolordark="#FFFFFF" bgColor="#FFFFFF">
			<tr align="left">
				<td colspan="2" nowrap>
				<img src="/surge_logo_2b.gif" alt="" border="0">
				</td>
			</tr>
			<tr>
				<td colspan="2" nowrap><hr noshade size="1">
				<h1>Phone Forwarding</h1>
			</tr>
			<tr>
				<td width="20%" nowrap>
				<p align="right">Extension No:</td>
				<td nowrap>
				<input type="text" name="EXTEN" maxlength="4" size="20" value="$EXTEN"></td>
			</tr>
			<tr>
				<td width="20%" nowrap>
				<p align="right">Fwd Destination:</td>
				<td nowrap><input type="text" name="FWD" value="$FWD" size="20" maxlength="11"></td>
			</tr>
			<tr>
				<td colspan="2" width="20%" nowrap>
				<hr noshade size="1">
				<p align="center">
				<input type="submit" value="Get FWD Info" name="GETFWD">
				<input type="submit" value="Set FWD" name="SETFWD" onclick="if ((FWD.value.length != 11)&&(FWD.value.length != 4)) {alert('FWD Destination must be 1+AREACODE+NUMBER without any other characters or a 4 digit extension.');return false;}">
				<input type="submit" value="Clear FWD" name="CLEARFWD">
				<hr noshade size="1">
				</td>
			</tr>
		</table>
		</td>
			</tr>
		</table>
	</div>
</form>

</body>

</html>
EOF



?>
