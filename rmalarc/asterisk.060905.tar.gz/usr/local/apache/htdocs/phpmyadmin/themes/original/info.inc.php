<?php
/* $Id: info.inc.php,v 2.1 2005/03/27 19:16:41 rabus Exp $ */
/* Theme information */
$theme_name = 'Original';
$theme_version = 2;
$theme_generation = 1;
?>
