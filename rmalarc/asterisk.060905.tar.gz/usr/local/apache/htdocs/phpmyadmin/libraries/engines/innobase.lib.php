<?php
/* $Id: innobase.lib.php,v 2.0 2005/03/05 13:24:28 rabus Exp $ */
// vim: expandtab sw=4 ts=4 sts=4:

include_once('./libraries/engines/innodb.lib.php');
class PMA_StorageEngine_innobase extends PMA_StorageEngine_innodb {}

?>
