<?php
/* $Id: berkeleydb.lib.php,v 2.0 2005/03/05 13:24:28 rabus Exp $ */
// vim: expandtab sw=4 ts=4 sts=4:

include_once('./libraries/engines/bdb.lib.php');
class PMA_StorageEngine_berkeleydb extends PMA_StorageEngine_bdb {}

?>
