<?


print "Hello to php";


?>
